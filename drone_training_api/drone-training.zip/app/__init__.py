"""Drone Training API package."""
